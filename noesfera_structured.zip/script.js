// script.js
// Archivo preparado para funciones interactivas futuras
console.log("Script cargado correctamente.");
